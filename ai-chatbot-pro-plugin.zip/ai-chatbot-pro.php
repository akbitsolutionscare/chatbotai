<?php
/**
 * Plugin Name: AI Chatbot Pro
 * Plugin URI: https://example.com/ai-chatbot-pro
 * Description: A comprehensive AI-powered chatbot for WordPress with OpenAI integration, conversation management, and GDPR compliance.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ai-chatbot-pro
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AI_CHATBOT_VERSION', '1.0.0');
define('AI_CHATBOT_PLUGIN_FILE', __FILE__);
define('AI_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AI_CHATBOT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AI_CHATBOT_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main AI Chatbot Pro class
 */
class AIChatbot_Pro {
    
    /**
     * Single instance of the class
     */
    private static $instance = null;
    
    /**
     * Plugin components
     */
    public $database;
    public $admin;
    public $frontend;
    public $api;
    public $security;
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init();
    }
    
    /**
     * Initialize the plugin
     */
    private function init() {
        // Load plugin files
        $this->load_dependencies();
        
        // Initialize components
        $this->init_components();
        
        // Setup hooks
        $this->setup_hooks();
        
        // Load text domain
        add_action('plugins_loaded', array($this, 'load_textdomain'));
    }
    
    /**
     * Load required files
     */
    private function load_dependencies() {
        require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-database.php';
        require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-admin.php';
        require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-frontend.php';
        require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-api.php';
        require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-security.php';
    }
    
    /**
     * Initialize plugin components
     */
    private function init_components() {
        $this->database = new AIChatbot_Database();
        $this->admin = new AIChatbot_Admin();
        $this->frontend = new AIChatbot_Frontend();
        $this->api = new AIChatbot_API();
        $this->security = new AIChatbot_Security();
    }
    
    /**
     * Setup WordPress hooks
     */
    private function setup_hooks() {
        // Activation and deactivation hooks
        register_activation_hook(AI_CHATBOT_PLUGIN_FILE, array($this, 'activate'));
        register_deactivation_hook(AI_CHATBOT_PLUGIN_FILE, array($this, 'deactivate'));
        register_uninstall_hook(AI_CHATBOT_PLUGIN_FILE, array('AIChatbot_Pro', 'uninstall'));
        
        // Admin hooks
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('admin_notices', array($this, 'admin_notices'));
        
        // Frontend hooks
        add_action('wp_enqueue_scripts', array($this, 'frontend_enqueue_scripts'));
        
        // AJAX hooks for admin
        add_action('wp_ajax_ai_chatbot_get_conversation', array($this, 'get_conversation_details'));
        add_action('wp_ajax_ai_chatbot_delete_faq', array($this, 'delete_faq'));
        
        // Settings link in plugins page
        add_filter('plugin_action_links_' . AI_CHATBOT_PLUGIN_BASENAME, array($this, 'plugin_action_links'));
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables
        AIChatbot_Database::create_tables();
        
        // Set default options
        $this->set_default_options();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Schedule cleanup task
        if (!wp_next_scheduled('ai_chatbot_cleanup_old_data')) {
            wp_schedule_event(time(), 'daily', 'ai_chatbot_cleanup_old_data');
        }
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clear scheduled tasks
        wp_clear_scheduled_hook('ai_chatbot_cleanup_old_data');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin uninstall
     */
    public static function uninstall() {
        global $wpdb;
        
        // Remove database tables
        $tables = array(
            $wpdb->prefix . 'ai_chatbot_users',
            $wpdb->prefix . 'ai_chatbot_conversations',
            $wpdb->prefix . 'ai_chatbot_messages',
            $wpdb->prefix . 'ai_chatbot_faq',
            $wpdb->prefix . 'ai_chatbot_content'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
        
        // Remove options
        $options = array(
            'ai_chatbot_widget_position',
            'ai_chatbot_primary_color',
            'ai_chatbot_greeting_message',
            'ai_chatbot_require_user_info',
            'ai_chatbot_enable_file_upload',
            'ai_chatbot_openai_api_key',
            'ai_chatbot_openai_model',
            'ai_chatbot_max_tokens',
            'ai_chatbot_temperature',
            'ai_chatbot_system_prompt',
            'ai_chatbot_auto_delete_days',
            'ai_chatbot_enable_encryption',
            'ai_chatbot_encryption_key'
        );
        
        foreach ($options as $option) {
            delete_option($option);
        }
        
        // Clear scheduled tasks
        wp_clear_scheduled_hook('ai_chatbot_cleanup_old_data');
    }
    
    /**
     * Set default plugin options
     */
    private function set_default_options() {
        $defaults = array(
            'ai_chatbot_widget_position' => 'bottom-right',
            'ai_chatbot_primary_color' => '#007cba',
            'ai_chatbot_greeting_message' => 'Hello! How can I help you today?',
            'ai_chatbot_require_user_info' => '1',
            'ai_chatbot_enable_file_upload' => '1',
            'ai_chatbot_openai_model' => 'gpt-3.5-turbo',
            'ai_chatbot_max_tokens' => '150',
            'ai_chatbot_temperature' => '0.7',
            'ai_chatbot_system_prompt' => 'You are a helpful assistant. Provide clear, concise, and helpful responses to user questions.',
            'ai_chatbot_auto_delete_days' => '30',
            'ai_chatbot_enable_encryption' => '0'
        );
        
        foreach ($defaults as $option => $value) {
            if (get_option($option) === false) {
                add_option($option, $value);
            }
        }
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function admin_enqueue_scripts($hook) {
        // Only load on our admin pages
        if (strpos($hook, 'ai-chatbot') === false) {
            return;
        }
        
        wp_enqueue_style(
            'ai-chatbot-admin',
            AI_CHATBOT_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            AI_CHATBOT_VERSION
        );
        
        wp_enqueue_script(
            'ai-chatbot-admin',
            AI_CHATBOT_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            AI_CHATBOT_VERSION,
            true
        );
        
        // Localize script
        wp_localize_script('ai-chatbot-admin', 'aiChatbotAdmin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_chatbot_admin_nonce')
        ));
        
        // Load Chart.js for analytics
        if ($hook === 'ai-chatbot_page_ai-chatbot-analytics') {
            wp_enqueue_script(
                'chart-js',
                'https://cdn.jsdelivr.net/npm/chart.js',
                array(),
                '3.9.1',
                true
            );
        }
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function frontend_enqueue_scripts() {
        // Don't load on admin pages
        if (is_admin()) {
            return;
        }
        
        wp_enqueue_style(
            'ai-chatbot-frontend',
            AI_CHATBOT_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            AI_CHATBOT_VERSION
        );
        
        wp_enqueue_script(
            'ai-chatbot-frontend',
            AI_CHATBOT_PLUGIN_URL . 'assets/js/frontend.js',
            array('jquery'),
            AI_CHATBOT_VERSION,
            true
        );
        
        // Localize script
        wp_localize_script('ai-chatbot-frontend', 'aiChatbot', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_chatbot_nonce'),
            'settings' => array(
                'widget_position' => get_option('ai_chatbot_widget_position', 'bottom-right'),
                'primary_color' => get_option('ai_chatbot_primary_color', '#007cba'),
                'greeting_message' => get_option('ai_chatbot_greeting_message', 'Hello! How can I help you today?'),
                'require_user_info' => get_option('ai_chatbot_require_user_info', '1'),
                'enable_file_upload' => get_option('ai_chatbot_enable_file_upload', '1')
            )
        ));
    }
    
    /**
     * Display admin notices
     */
    public function admin_notices() {
        // Check if OpenAI API key is set
        if (empty(get_option('ai_chatbot_openai_api_key'))) {
            $settings_url = admin_url('admin.php?page=ai-chatbot-settings');
            echo '<div class="notice notice-warning is-dismissible">';
            echo '<p><strong>AI Chatbot Pro:</strong> Please configure your OpenAI API key in the <a href="' . esc_url($settings_url) . '">settings</a> to enable AI responses.</p>';
            echo '</div>';
        }
    }
    
    /**
     * Add settings link to plugins page
     */
    public function plugin_action_links($links) {
        $settings_link = '<a href="' . admin_url('admin.php?page=ai-chatbot-settings') . '">' . __('Settings', 'ai-chatbot-pro') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
    
    /**
     * Get conversation details for admin modal
     */
    public function get_conversation_details() {
        check_ajax_referer('ai_chatbot_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
            return;
        }
        
        $conversation_id = intval($_POST['conversation_id']);
        
        if (!$conversation_id) {
            wp_send_json_error('Invalid conversation ID');
            return;
        }
        
        $messages = AIChatbot_Database::get_conversation_messages($conversation_id);
        
        wp_send_json_success(array(
            'messages' => $messages
        ));
    }
    
    /**
     * Delete FAQ item
     */
    public function delete_faq() {
        check_ajax_referer('ai_chatbot_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
            return;
        }
        
        $faq_id = intval($_POST['faq_id']);
        
        if (!$faq_id) {
            wp_send_json_error('Invalid FAQ ID');
            return;
        }
        
        global $wpdb;
        
        $faq_table = $wpdb->prefix . 'ai_chatbot_faq';
        $result = $wpdb->delete($faq_table, array('id' => $faq_id));
        
        if ($result) {
            wp_send_json_success('FAQ deleted successfully');
        } else {
            wp_send_json_error('Failed to delete FAQ');
        }
    }
    
    /**
     * Load plugin text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'ai-chatbot-pro',
            false,
            dirname(AI_CHATBOT_PLUGIN_BASENAME) . '/languages'
        );
    }
    
    /**
     * Get plugin version
     */
    public function get_version() {
        return AI_CHATBOT_VERSION;
    }
    
    /**
     * Check if plugin requirements are met
     */
    public function check_requirements() {
        $requirements = array(
            'php_version' => '7.4',
            'wp_version' => '5.0',
            'extensions' => array('curl', 'json', 'openssl')
        );
        
        $errors = array();
        
        // Check PHP version
        if (version_compare(PHP_VERSION, $requirements['php_version'], '<')) {
            $errors[] = sprintf('PHP version %s or higher is required.', $requirements['php_version']);
        }
        
        // Check WordPress version
        global $wp_version;
        if (version_compare($wp_version, $requirements['wp_version'], '<')) {
            $errors[] = sprintf('WordPress version %s or higher is required.', $requirements['wp_version']);
        }
        
        // Check PHP extensions
        foreach ($requirements['extensions'] as $extension) {
            if (!extension_loaded($extension)) {
                $errors[] = sprintf('PHP extension %s is required.', $extension);
            }
        }
        
        return empty($errors) ? true : $errors;
    }
}

/**
 * Initialize the plugin
 */
function ai_chatbot_pro_init() {
    return AIChatbot_Pro::get_instance();
}

// Start the plugin
ai_chatbot_pro_init();

/**
 * Helper function to get plugin instance
 */
function ai_chatbot_pro() {
    return AIChatbot_Pro::get_instance();
}
?>
