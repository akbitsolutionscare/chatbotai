/**
 * AI Chatbot Pro Admin JavaScript
 */

(function($) {
    'use strict';

    class AIChatbotAdmin {
        constructor() {
            this.init();
        }

        init() {
            this.initTabs();
            this.bindEvents();
            this.initCharts();
        }

        initTabs() {
            // Settings page tabs
            $('.nav-tab').on('click', function(e) {
                e.preventDefault();
                
                const target = $(this).attr('href');
                
                // Update active tab
                $('.nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                // Show corresponding content
                $('.tab-content').removeClass('active');
                $(target).addClass('active');
            });
        }

        bindEvents() {
            // Select all checkbox
            $('#select-all').on('change', function() {
                $('input[name="conversation_ids[]"]').prop('checked', this.checked);
            });

            // Bulk actions
            $('#apply-bulk-action').on('click', () => {
                this.handleBulkAction();
            });

            // Delete conversation
            $(document).on('click', '.delete-conversation', (e) => {
                e.preventDefault();
                this.deleteConversation($(e.target).data('id'));
            });

            // View conversation
            $(document).on('click', '.view-conversation', (e) => {
                e.preventDefault();
                this.viewConversation($(e.target).data('id'));
            });

            // Export user data
            $(document).on('click', '.export-user-data', (e) => {
                e.preventDefault();
                this.exportUserData($(e.target).data('id'));
            });

            // Anonymize user
            $(document).on('click', '.anonymize-user', (e) => {
                e.preventDefault();
                this.anonymizeUser($(e.target).data('id'));
            });

            // Close modal
            $(document).on('click', '.close, .ai-chatbot-modal', (e) => {
                if (e.target === e.currentTarget) {
                    this.closeModal();
                }
            });

            // Edit FAQ
            $(document).on('click', '.edit-faq', (e) => {
                e.preventDefault();
                this.editFAQ($(e.target).data('id'));
            });

            // Delete FAQ
            $(document).on('click', '.delete-faq', (e) => {
                e.preventDefault();
                this.deleteFAQ($(e.target).data('id'));
            });
        }

        handleBulkAction() {
            const action = $('#bulk-action').val();
            const selectedIds = $('input[name="conversation_ids[]"]:checked').map(function() {
                return this.value;
            }).get();

            if (!action) {
                alert('Please select an action.');
                return;
            }

            if (selectedIds.length === 0) {
                alert('Please select at least one conversation.');
                return;
            }

            if (action === 'delete') {
                if (confirm('Are you sure you want to delete the selected conversations? This action cannot be undone.')) {
                    this.bulkDeleteConversations(selectedIds);
                }
            } else if (action === 'export') {
                this.bulkExportConversations(selectedIds);
            }
        }

        deleteConversation(conversationId) {
            if (!confirm('Are you sure you want to delete this conversation? This action cannot be undone.')) {
                return;
            }

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'ai_chatbot_delete_conversation',
                    conversation_id: conversationId,
                    nonce: $('#_wpnonce').val()
                },
                success: (response) => {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                    }
                },
                error: () => {
                    alert('Connection error. Please try again.');
                }
            });
        }

        bulkDeleteConversations(conversationIds) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'ai_chatbot_bulk_delete',
                    conversation_ids: conversationIds,
                    nonce: $('#_wpnonce').val()
                },
                success: (response) => {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                    }
                },
                error: () => {
                    alert('Connection error. Please try again.');
                }
            });
        }

        viewConversation(conversationId) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'ai_chatbot_get_conversation',
                    conversation_id: conversationId,
                    nonce: $('#_wpnonce').val()
                },
                success: (response) => {
                    if (response.success) {
                        this.showConversationModal(response.data);
                    } else {
                        alert('Error: ' + response.data);
                    }
                },
                error: () => {
                    alert('Connection error. Please try again.');
                }
            });
        }

        showConversationModal(conversationData) {
            let messagesHtml = '';
            
            conversationData.messages.forEach(message => {
                const messageClass = message.sender_type === 'user' ? 'user-message' : 'bot-message';
                const senderName = message.sender_type === 'user' ? 'User' : 'AI Assistant';
                const timestamp = new Date(message.created_at).toLocaleString();
                
                messagesHtml += `
                    <div class="conversation-message ${messageClass}">
                        <div class="message-meta">
                            <strong>${senderName}</strong> - ${timestamp}
                        </div>
                        <div class="message-content">${this.escapeHtml(message.message)}</div>
                    </div>
                `;
            });

            $('#conversation-messages').html(messagesHtml);
            $('#conversation-modal').show();
        }

        exportUserData(userId) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'ai_chatbot_export_user_data',
                    user_id: userId,
                    nonce: $('#_wpnonce').val()
                },
                success: (response) => {
                    if (response.success) {
                        this.downloadFile(response.data.data, response.data.filename, 'application/json');
                    } else {
                        alert('Error: ' + response.data);
                    }
                },
                error: () => {
                    alert('Connection error. Please try again.');
                }
            });
        }

        anonymizeUser(userId) {
            if (!confirm('Are you sure you want to anonymize this user\'s data? This action cannot be undone.')) {
                return;
            }

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'ai_chatbot_anonymize_user',
                    user_id: userId,
                    nonce: $('#_wpnonce').val()
                },
                success: (response) => {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                    }
                },
                error: () => {
                    alert('Connection error. Please try again.');
                }
            });
        }

        editFAQ(faqId) {
            // Implementation for editing FAQ
            // This would typically open a modal or redirect to an edit page
            console.log('Edit FAQ:', faqId);
        }

        deleteFAQ(faqId) {
            if (!confirm('Are you sure you want to delete this FAQ? This action cannot be undone.')) {
                return;
            }

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'ai_chatbot_delete_faq',
                    faq_id: faqId,
                    nonce: $('#_wpnonce').val()
                },
                success: (response) => {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                    }
                },
                error: () => {
                    alert('Connection error. Please try again.');
                }
            });
        }

        closeModal() {
            $('.ai-chatbot-modal').hide();
        }

        downloadFile(content, filename, contentType) {
            const blob = new Blob([content], { type: contentType });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        initCharts() {
            // Initialize charts if Chart.js is available
            if (typeof Chart !== 'undefined') {
                this.initConversationsChart();
                this.initRatingsChart();
            }
        }

        initConversationsChart() {
            const ctx = document.getElementById('conversationsChart');
            if (!ctx) return;

            // Sample data - in real implementation, this would come from the server
            const data = {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Conversations',
                    data: [12, 19, 3, 5, 2, 3, 9],
                    borderColor: '#007cba',
                    backgroundColor: 'rgba(0, 124, 186, 0.1)',
                    tension: 0.4
                }]
            };

            new Chart(ctx, {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        initRatingsChart() {
            const ctx = document.getElementById('ratingsChart');
            if (!ctx) return;

            // Sample data - in real implementation, this would come from the server
            const data = {
                labels: ['1 Star', '2 Stars', '3 Stars', '4 Stars', '5 Stars'],
                datasets: [{
                    data: [2, 5, 8, 15, 25],
                    backgroundColor: [
                        '#dc3545',
                        '#fd7e14',
                        '#ffc107',
                        '#28a745',
                        '#007cba'
                    ]
                }]
            };

            new Chart(ctx, {
                type: 'doughnut',
                data: data,
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
    }

    // Initialize admin functionality when DOM is ready
    $(document).ready(function() {
        new AIChatbotAdmin();
    });

    // Color picker initialization
    $(document).ready(function() {
        if ($.fn.wpColorPicker) {
            $('input[type="color"]').wpColorPicker();
        }
    });

    // Auto-save settings
    let saveTimeout;
    $('.form-table input, .form-table select, .form-table textarea').on('change', function() {
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
            // Auto-save functionality could be implemented here
            console.log('Auto-saving settings...');
        }, 2000);
    });

    // Real-time validation
    $('#user-email').on('blur', function() {
        const email = $(this).val();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (email && !emailRegex.test(email)) {
            $(this).addClass('error');
            $(this).after('<span class="error-message">Please enter a valid email address.</span>');
        } else {
            $(this).removeClass('error');
            $(this).siblings('.error-message').remove();
        }
    });

    // Keyboard shortcuts
    $(document).on('keydown', function(e) {
        // Ctrl/Cmd + S to save settings
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            $('.button-primary[type="submit"]').click();
        }
        
        // Escape to close modals
        if (e.key === 'Escape') {
            $('.ai-chatbot-modal').hide();
        }
    });

    // Tooltips
    $(document).ready(function() {
        $('[data-tooltip]').each(function() {
            $(this).attr('title', $(this).data('tooltip'));
        });
    });

    // Confirmation dialogs
    $('.delete-action').on('click', function(e) {
        if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
            e.preventDefault();
        }
    });

    // Loading states
    $('form').on('submit', function() {
        $(this).find('.button-primary').addClass('loading').prop('disabled', true);
    });

    // AJAX error handling
    $(document).ajaxError(function(event, xhr, settings, thrownError) {
        console.error('AJAX Error:', thrownError);
        alert('An error occurred. Please try again.');
    });

})(jQuery);
