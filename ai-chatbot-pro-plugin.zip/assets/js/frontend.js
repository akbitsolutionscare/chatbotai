/**
 * AI Chatbot Pro Frontend JavaScript
 */

(function($) {
    'use strict';

    class AIChatbotWidget {
        constructor() {
            this.isOpen = false;
            this.sessionId = this.generateSessionId();
            this.conversationId = null;
            this.userId = null;
            this.isTyping = false;
            this.messageHistory = [];
            
            this.init();
        }

        init() {
            this.bindEvents();
            this.loadChatHistory();
            this.setupAutoResize();
        }

        bindEvents() {
            // Toggle chat widget
            $(document).on('click', '#ai-chatbot-toggle', (e) => {
                e.preventDefault();
                this.toggleChat();
            });

            // Minimize chat
            $(document).on('click', '#chatbot-minimize', (e) => {
                e.preventDefault();
                this.minimizeChat();
            });

            // Submit user info form
            $(document).on('submit', '#user-info-form', (e) => {
                e.preventDefault();
                this.submitUserInfo();
            });

            // Send message
            $(document).on('click', '#send-message', (e) => {
                e.preventDefault();
                this.sendMessage();
            });

            // Handle Enter key in message input
            $(document).on('keydown', '#message-input', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });

            // Quick reply buttons
            $(document).on('click', '.quick-reply-btn', (e) => {
                e.preventDefault();
                const message = $(e.target).data('message');
                $('#message-input').val(message);
                this.sendMessage();
            });

            // Rating stars
            $(document).on('click', '.star-btn', (e) => {
                e.preventDefault();
                this.rateConversation($(e.target).data('rating'));
            });

            // Download transcript
            $(document).on('click', '#download-transcript', (e) => {
                e.preventDefault();
                this.downloadTranscript();
            });

            // File upload
            $(document).on('change', '#file-upload', (e) => {
                this.handleFileUpload(e.target.files[0]);
            });
        }

        generateSessionId() {
            return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
        }

        toggleChat() {
            const $toggle = $('#ai-chatbot-toggle');
            const $container = $('#ai-chatbot-container');

            if (this.isOpen) {
                this.minimizeChat();
            } else {
                $container.show();
                $toggle.addClass('active');
                this.isOpen = true;
                
                // Show appropriate section
                if (this.userId) {
                    this.showChatInterface();
                } else if (aiChatbot.settings.require_user_info === '1') {
                    this.showPreChatForm();
                } else {
                    this.createAnonymousUser();
                }
            }
        }

        minimizeChat() {
            const $toggle = $('#ai-chatbot-toggle');
            const $container = $('#ai-chatbot-container');

            $container.hide();
            $toggle.removeClass('active');
            this.isOpen = false;
        }

        showPreChatForm() {
            $('#pre-chat-form').show();
            $('#chat-messages, #chat-input-area, #chat-footer').hide();
        }

        showChatInterface() {
            $('#pre-chat-form').hide();
            $('#chat-messages, #chat-input-area, #chat-footer').show();
            this.scrollToBottom();
            $('#message-input').focus();
        }

        submitUserInfo() {
            const formData = {
                action: 'ai_chatbot_save_user',
                nonce: aiChatbot.nonce,
                name: $('#user-name').val().trim(),
                email: $('#user-email').val().trim(),
                phone: $('#user-phone').val().trim(),
                session_id: this.sessionId
            };

            if (!formData.name || !formData.email) {
                this.showError('Please fill in all required fields.');
                return;
            }

            if (!this.isValidEmail(formData.email)) {
                this.showError('Please enter a valid email address.');
                return;
            }

            this.showLoading('#user-info-form .start-chat-btn');

            $.ajax({
                url: aiChatbot.ajax_url,
                type: 'POST',
                data: formData,
                success: (response) => {
                    this.hideLoading('#user-info-form .start-chat-btn');
                    
                    if (response.success) {
                        this.userId = response.data.user_id;
                        this.conversationId = response.data.conversation_id;
                        this.showChatInterface();
                        this.saveToLocalStorage();
                    } else {
                        this.showError(response.data || 'Failed to save user information.');
                    }
                },
                error: () => {
                    this.hideLoading('#user-info-form .start-chat-btn');
                    this.showError('Connection error. Please try again.');
                }
            });
        }

        createAnonymousUser() {
            const formData = {
                action: 'ai_chatbot_save_user',
                nonce: aiChatbot.nonce,
                name: 'Anonymous User',
                email: 'anonymous@example.com',
                phone: '',
                session_id: this.sessionId
            };

            $.ajax({
                url: aiChatbot.ajax_url,
                type: 'POST',
                data: formData,
                success: (response) => {
                    if (response.success) {
                        this.userId = response.data.user_id;
                        this.conversationId = response.data.conversation_id;
                        this.showChatInterface();
                        this.saveToLocalStorage();
                    }
                }
            });
        }

        sendMessage() {
            const message = $('#message-input').val().trim();
            
            if (!message || this.isTyping) {
                return;
            }

            // Add user message to chat
            this.addMessage('user', message);
            $('#message-input').val('');
            this.hideQuickReplies();

            // Show typing indicator
            this.showTypingIndicator();

            const messageData = {
                action: 'ai_chatbot_send_message',
                nonce: aiChatbot.nonce,
                message: message,
                session_id: this.sessionId,
                conversation_id: this.conversationId
            };

            $.ajax({
                url: aiChatbot.ajax_url,
                type: 'POST',
                data: messageData,
                success: (response) => {
                    this.hideTypingIndicator();
                    
                    if (response.success) {
                        this.addMessage('bot', response.data.response, response.data.source);
                        this.showQuickReplies();
                    } else {
                        this.addMessage('bot', 'Sorry, I encountered an error. Please try again.');
                    }
                },
                error: () => {
                    this.hideTypingIndicator();
                    this.addMessage('bot', 'Connection error. Please check your internet connection and try again.');
                }
            });
        }

        addMessage(sender, content, source = null) {
            const timestamp = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            const messageClass = sender === 'user' ? 'user-message' : 'bot-message';
            
            const messageHtml = `
                <div class="message ${messageClass}">
                    <div class="message-content">${this.formatMessage(content)}</div>
                    <div class="message-time">${timestamp}</div>
                </div>
            `;

            $('#chat-messages').append(messageHtml);
            this.scrollToBottom();
            
            // Store in message history
            this.messageHistory.push({
                sender: sender,
                content: content,
                timestamp: new Date().toISOString(),
                source: source
            });
            
            this.saveToLocalStorage();
        }

        formatMessage(message) {
            // Basic markdown support
            message = message.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            message = message.replace(/\*(.*?)\*/g, '<em>$1</em>');
            message = message.replace(/`(.*?)`/g, '<code>$1</code>');
            
            // Convert URLs to links
            message = message.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
            
            // Convert line breaks
            message = message.replace(/\n/g, '<br>');
            
            return message;
        }

        showTypingIndicator() {
            this.isTyping = true;
            $('#typing-indicator').show();
            this.scrollToBottom();
        }

        hideTypingIndicator() {
            this.isTyping = false;
            $('#typing-indicator').hide();
        }

        showQuickReplies() {
            $('#quick-replies').show();
        }

        hideQuickReplies() {
            $('#quick-replies').hide();
        }

        scrollToBottom() {
            const $messages = $('#chat-messages');
            $messages.scrollTop($messages[0].scrollHeight);
        }

        rateConversation(rating) {
            $('.star-btn').removeClass('active');
            $(`.star-btn[data-rating="${rating}"]`).prevAll().addBack().addClass('active');

            const ratingData = {
                action: 'ai_chatbot_rate_conversation',
                nonce: aiChatbot.nonce,
                conversation_id: this.conversationId,
                rating: rating,
                feedback: ''
            };

            $.ajax({
                url: aiChatbot.ajax_url,
                type: 'POST',
                data: ratingData,
                success: (response) => {
                    if (response.success) {
                        this.showSuccess('Thank you for your feedback!');
                    }
                }
            });
        }

        downloadTranscript() {
            let transcript = 'Chat Transcript\n';
            transcript += 'Generated on: ' + new Date().toLocaleString() + '\n\n';

            this.messageHistory.forEach(msg => {
                const sender = msg.sender === 'user' ? 'You' : 'AI Assistant';
                const time = new Date(msg.timestamp).toLocaleTimeString();
                transcript += `[${time}] ${sender}: ${msg.content}\n`;
            });

            const blob = new Blob([transcript], { type: 'text/plain' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `chat-transcript-${new Date().toISOString().slice(0, 10)}.txt`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }

        handleFileUpload(file) {
            if (!file) return;

            const maxSize = 5 * 1024 * 1024; // 5MB
            const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'text/plain'];

            if (file.size > maxSize) {
                this.showError('File size must be less than 5MB.');
                return;
            }

            if (!allowedTypes.includes(file.type)) {
                this.showError('File type not supported. Please upload images, PDF, or text files.');
                return;
            }

            // For demo purposes, just show file name
            this.addMessage('user', `📎 Uploaded: ${file.name}`);
            this.addMessage('bot', 'Thank you for sharing the file. I can see you uploaded ' + file.name + '. How can I help you with this file?');
        }

        setupAutoResize() {
            $(document).on('input', '#message-input', function() {
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 100) + 'px';
            });
        }

        loadChatHistory() {
            const saved = localStorage.getItem('ai_chatbot_' + this.sessionId);
            if (saved) {
                const data = JSON.parse(saved);
                this.userId = data.userId;
                this.conversationId = data.conversationId;
                this.messageHistory = data.messageHistory || [];
                
                // Restore messages
                this.messageHistory.forEach(msg => {
                    const timestamp = new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                    const messageClass = msg.sender === 'user' ? 'user-message' : 'bot-message';
                    
                    const messageHtml = `
                        <div class="message ${messageClass}">
                            <div class="message-content">${this.formatMessage(msg.content)}</div>
                            <div class="message-time">${timestamp}</div>
                        </div>
                    `;
                    
                    $('#chat-messages .welcome-message').after(messageHtml);
                });
            }
        }

        saveToLocalStorage() {
            const data = {
                userId: this.userId,
                conversationId: this.conversationId,
                messageHistory: this.messageHistory,
                timestamp: new Date().toISOString()
            };
            
            localStorage.setItem('ai_chatbot_' + this.sessionId, JSON.stringify(data));
        }

        showLoading(selector) {
            $(selector).addClass('loading').prop('disabled', true);
        }

        hideLoading(selector) {
            $(selector).removeClass('loading').prop('disabled', false);
        }

        showError(message) {
            const errorHtml = `<div class="error-message">${message}</div>`;
            $('.pre-chat-form, .chat-input-area').prepend(errorHtml);
            setTimeout(() => $('.error-message').fadeOut(), 5000);
        }

        showSuccess(message) {
            const successHtml = `<div class="success-message">${message}</div>`;
            $('.chat-footer').prepend(successHtml);
            setTimeout(() => $('.success-message').fadeOut(), 3000);
        }

        isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }
    }

    // Initialize the chatbot when DOM is ready
    $(document).ready(function() {
        // Only initialize if the widget exists on the page
        if ($('#ai-chatbot-widget').length) {
            new AIChatbotWidget();
        }
    });

    // Handle page visibility changes
    document.addEventListener('visibilitychange', function() {
        if (document.visibilityState === 'visible') {
            // Page became visible, could refresh chat status
        }
    });

    // Handle window resize for responsive behavior
    $(window).on('resize', function() {
        // Adjust chat widget position if needed
        const $widget = $('#ai-chatbot-widget');
        if ($widget.length && window.innerWidth <= 480) {
            // Mobile adjustments
        }
    });

})(jQuery);
