# AI Chatbot Pro - WordPress Plugin

A comprehensive AI-powered chatbot plugin for WordPress with OpenAI integration, conversation management, and GDPR compliance.

## Features

### Core Features
- **AI-Powered Conversations**: Integration with OpenAI GPT models for intelligent responses
- **Customizable Chat Widget**: Fully customizable chat interface with multiple positioning options
- **User Management**: Collect and manage user information with GDPR compliance
- **Conversation History**: Store and manage all chat conversations
- **FAQ Knowledge Base**: Create and manage frequently asked questions
- **File Upload Support**: Allow users to upload files during conversations
- **Rating System**: Users can rate their chat experience
- **Multi-language Support**: Ready for translation

### Admin Features
- **Comprehensive Dashboard**: Overview of conversations, users, and analytics
- **Conversation Management**: View, search, and manage all conversations
- **User Management**: Manage user data with export and anonymization options
- **FAQ Management**: Create, edit, and organize frequently asked questions
- **Analytics**: Detailed analytics and reporting
- **Settings Management**: Extensive customization options

### Security & Privacy
- **GDPR Compliance**: Data export, anonymization, and deletion features
- **Data Encryption**: Optional encryption for sensitive data
- **Rate Limiting**: Prevent abuse with built-in rate limiting
- **Security Headers**: Enhanced security with proper headers
- **Input Sanitization**: All inputs are properly sanitized and validated

## Installation

1. **Download the Plugin**
   - Download the plugin files or clone this repository
   - Ensure all files are in a folder named `ai-chatbot-pro`

2. **Upload to WordPress**
   - Upload the plugin folder to `/wp-content/plugins/`
   - Or upload the ZIP file through WordPress admin

3. **Activate the Plugin**
   - Go to WordPress Admin → Plugins
   - Find "AI Chatbot Pro" and click "Activate"

4. **Configure Settings**
   - Go to AI Chatbot → Settings
   - Add your OpenAI API key
   - Configure other settings as needed

## Configuration

### OpenAI API Setup

1. **Get API Key**
   - Visit [OpenAI Platform](https://platform.openai.com/)
   - Create an account or sign in
   - Go to API Keys section
   - Create a new API key

2. **Configure in Plugin**
   - Go to AI Chatbot → Settings → AI Settings
   - Enter your OpenAI API key
   - Select the model (gpt-3.5-turbo recommended)
   - Adjust temperature and max tokens as needed

### Widget Customization

1. **Position Settings**
   - Choose widget position (bottom-right, bottom-left, etc.)
   - Customize primary color
   - Set greeting message

2. **User Information**
   - Enable/disable user information collection
   - Configure required fields
   - Set up file upload options

### FAQ Management

1. **Add FAQs**
   - Go to AI Chatbot → FAQ
   - Add questions and answers
   - Organize by categories

2. **Knowledge Base**
   - FAQs are automatically searched before AI responses
   - Track usage statistics
   - Update based on common questions

## Usage

### For Site Visitors

1. **Starting a Chat**
   - Click the chat widget on your website
   - Fill in required information (if enabled)
   - Start typing your questions

2. **Chat Features**
   - Send text messages
   - Upload files (if enabled)
   - Use quick reply buttons
   - Rate the conversation
   - Download chat transcript

### For Administrators

1. **Dashboard Overview**
   - View conversation statistics
   - Monitor user activity
   - Check recent conversations

2. **Managing Conversations**
   - View all conversations
   - Search and filter
   - Export conversation data
   - Delete conversations

3. **User Management**
   - View user information
   - Export user data (GDPR)
   - Anonymize user data
   - Delete user accounts

4. **Analytics**
   - View conversation trends
   - Monitor response times
   - Check user satisfaction ratings
   - Export analytics data

## File Structure

```
ai-chatbot-pro/
├── ai-chatbot-pro.php          # Main plugin file
├── README.md                   # This file
├── includes/                   # Core plugin classes
│   ├── class-database.php      # Database operations
│   ├── class-admin.php         # Admin interface
│   ├── class-frontend.php      # Frontend widget
│   ├── class-api.php           # API handlers
│   └── class-security.php      # Security features
├── assets/                     # Static assets
│   ├── css/                    # Stylesheets
│   │   ├── frontend.css        # Frontend styles
│   │   └── admin.css           # Admin styles
│   └── js/                     # JavaScript files
│       ├── frontend.js         # Frontend functionality
│       └── admin.js            # Admin functionality
└── languages/                  # Translation files (future)
```

## Database Tables

The plugin creates the following database tables:

- `wp_ai_chatbot_users` - User information
- `wp_ai_chatbot_conversations` - Conversation records
- `wp_ai_chatbot_messages` - Individual messages
- `wp_ai_chatbot_faq` - FAQ entries
- `wp_ai_chatbot_content` - Crawled content (future feature)

## Hooks and Filters

### Actions
- `ai_chatbot_before_message_send` - Before sending a message
- `ai_chatbot_after_message_send` - After sending a message
- `ai_chatbot_conversation_started` - When a conversation starts
- `ai_chatbot_conversation_ended` - When a conversation ends

### Filters
- `ai_chatbot_widget_settings` - Modify widget settings
- `ai_chatbot_message_content` - Filter message content
- `ai_chatbot_ai_response` - Modify AI responses
- `ai_chatbot_user_data` - Filter user data before saving

## Requirements

- **WordPress**: 5.0 or higher
- **PHP**: 7.4 or higher
- **MySQL**: 5.6 or higher
- **PHP Extensions**: curl, json, openssl
- **OpenAI API Key**: Required for AI functionality

## Troubleshooting

### Common Issues

1. **Chat Widget Not Appearing**
   - Check if plugin is activated
   - Verify no JavaScript errors in console
   - Check if theme conflicts exist

2. **AI Responses Not Working**
   - Verify OpenAI API key is correct
   - Check API quota and billing
   - Review error logs

3. **Database Errors**
   - Check database permissions
   - Verify table creation
   - Review WordPress debug logs

### Debug Mode

Enable WordPress debug mode to troubleshoot issues:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

## Security Considerations

1. **API Key Security**
   - Store API keys securely
   - Use environment variables when possible
   - Regularly rotate API keys

2. **Data Protection**
   - Enable encryption for sensitive data
   - Regular data cleanup
   - Monitor access logs

3. **User Privacy**
   - Implement proper consent mechanisms
   - Provide data export/deletion options
   - Follow GDPR guidelines

## Performance Optimization

1. **Caching**
   - Cache FAQ responses
   - Implement conversation caching
   - Use object caching when available

2. **Database Optimization**
   - Regular cleanup of old data
   - Index optimization
   - Query optimization

3. **Asset Optimization**
   - Minify CSS/JS files
   - Use CDN for assets
   - Optimize images

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This plugin is licensed under the GPL v2 or later.

## Support

For support and questions:
- Check the documentation
- Review common issues
- Contact plugin author

## Changelog

### Version 1.0.0
- Initial release
- Core chatbot functionality
- OpenAI integration
- Admin dashboard
- GDPR compliance features
- Security enhancements

## Roadmap

### Future Features
- Multi-language AI responses
- Voice message support
- Advanced analytics
- Integration with popular page builders
- Mobile app support
- Advanced AI training options

---

**Note**: This plugin requires an OpenAI API key to function properly. Make sure to configure it in the settings after installation.
