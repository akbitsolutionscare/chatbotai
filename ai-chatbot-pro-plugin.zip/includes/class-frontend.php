<?php
/**
 * Frontend class for AI Chatbot Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIChatbot_Frontend {
    
    public function __construct() {
        add_action('wp_footer', array($this, 'render_chat_widget'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('ai-chatbot-frontend', AI_CHATBOT_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), AI_CHATBOT_VERSION, true);
        wp_enqueue_style('ai-chatbot-frontend', AI_CHATBOT_PLUGIN_URL . 'assets/css/frontend.css', array(), AI_CHATBOT_VERSION);
        
        // Localize script for AJAX
        wp_localize_script('ai-chatbot-frontend', 'aiChatbot', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_chatbot_nonce'),
            'settings' => $this->get_frontend_settings()
        ));
    }
    
    private function get_frontend_settings() {
        return array(
            'widget_position' => get_option('ai_chatbot_widget_position', 'bottom-right'),
            'primary_color' => get_option('ai_chatbot_primary_color', '#007cba'),
            'greeting_message' => get_option('ai_chatbot_greeting_message', 'Hello! How can I help you today?'),
            'require_user_info' => get_option('ai_chatbot_require_user_info', '1'),
            'enable_file_upload' => get_option('ai_chatbot_enable_file_upload', '1')
        );
    }
    
    public function render_chat_widget() {
        $settings = $this->get_frontend_settings();
        ?>
        
        <!-- AI Chatbot Widget -->
        <div id="ai-chatbot-widget" class="ai-chatbot-widget <?php echo esc_attr($settings['widget_position']); ?>" style="--primary-color: <?php echo esc_attr($settings['primary_color']); ?>">
            
            <!-- Chat Toggle Button -->
            <div id="ai-chatbot-toggle" class="chatbot-toggle">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2ZM20 16H5.17L4 17.17V4H20V16Z" fill="white"/>
                    <path d="M7 9H17V11H7V9ZM7 12H15V14H7V12Z" fill="white"/>
                </svg>
                <span class="close-icon" style="display: none;">×</span>
            </div>
            
            <!-- Chat Container -->
            <div id="ai-chatbot-container" class="chatbot-container" style="display: none;">
                
                <!-- Chat Header -->
                <div class="chatbot-header">
                    <div class="header-content">
                        <div class="bot-avatar">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 2C13.1 2 14 2.9 14 4C14 5.1 13.1 6 12 6C10.9 6 10 5.1 10 4C10 2.9 10.9 2 12 2ZM21 9V7L15 1H5C3.89 1 3 1.89 3 3V19C3 20.1 3.9 21 5 21H11V19H5V3H13V9H21Z" fill="white"/>
                            </svg>
                        </div>
                        <div class="header-text">
                            <h4>AI Assistant</h4>
                            <span class="status">Online</span>
                        </div>
                    </div>
                    <button id="chatbot-minimize" class="minimize-btn">−</button>
                </div>
                
                <!-- Pre-chat Form -->
                <div id="pre-chat-form" class="pre-chat-form">
                    <div class="form-content">
                        <h3>Welcome! Please tell us about yourself</h3>
                        <form id="user-info-form">
                            <div class="form-group">
                                <label for="user-name">Name *</label>
                                <input type="text" id="user-name" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="user-email">Email *</label>
                                <input type="email" id="user-email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="user-phone">Phone</label>
                                <input type="tel" id="user-phone" name="phone">
                            </div>
                            <button type="submit" class="start-chat-btn">Start Chat</button>
                        </form>
                    </div>
                </div>
                
                <!-- Chat Messages Area -->
                <div id="chat-messages" class="chat-messages" style="display: none;">
                    <div class="welcome-message">
                        <div class="message bot-message">
                            <div class="message-content">
                                <?php echo esc_html($settings['greeting_message']); ?>
                            </div>
                            <div class="message-time"><?php echo date('H:i'); ?></div>
                        </div>
                    </div>
                </div>
                
                <!-- Typing Indicator -->
                <div id="typing-indicator" class="typing-indicator" style="display: none;">
                    <div class="typing-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <span class="typing-text">AI is typing...</span>
                </div>
                
                <!-- Chat Input Area -->
                <div id="chat-input-area" class="chat-input-area" style="display: none;">
                    <div class="input-container">
                        <div class="file-upload-area" style="display: none;">
                            <input type="file" id="file-upload" accept="image/*,.pdf,.doc,.docx,.txt">
                            <label for="file-upload" class="file-upload-btn">📎</label>
                        </div>
                        
                        <div class="message-input-container">
                            <textarea id="message-input" placeholder="Type your message..." rows="1"></textarea>
                            <button id="send-message" class="send-btn">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M2.01 21L23 12L2.01 3L2 10L17 12L2 14L2.01 21Z" fill="currentColor"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Quick Reply Buttons -->
                    <div id="quick-replies" class="quick-replies" style="display: none;">
                        <button class="quick-reply-btn" data-message="What are your business hours?">Business Hours</button>
                        <button class="quick-reply-btn" data-message="How can I contact support?">Contact Support</button>
                        <button class="quick-reply-btn" data-message="Tell me about your services">Our Services</button>
                    </div>
                </div>
                
                <!-- Chat Footer -->
                <div id="chat-footer" class="chat-footer" style="display: none;">
                    <div class="footer-actions">
                        <button id="download-transcript" class="footer-btn">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 9H15V3H9V9H5L12 16L19 9ZM5 18V20H19V18H5Z" fill="currentColor"/>
                            </svg>
                            Download Chat
                        </button>
                        
                        <div class="rating-container">
                            <span>Rate this chat:</span>
                            <div class="rating-stars">
                                <button class="star-btn" data-rating="1">⭐</button>
                                <button class="star-btn" data-rating="2">⭐</button>
                                <button class="star-btn" data-rating="3">⭐</button>
                                <button class="star-btn" data-rating="4">⭐</button>
                                <button class="star-btn" data-rating="5">⭐</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php
    }
}
?>
