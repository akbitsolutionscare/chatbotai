<?php
/**
 * Security class for AI Chatbot Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIChatbot_Security {
    
    public function __construct() {
        add_action('init', array($this, 'init_security'));
        add_action('wp_ajax_ai_chatbot_anonymize_user', array($this, 'anonymize_user_data'));
        add_action('wp_ajax_ai_chatbot_export_user_data', array($this, 'export_user_data'));
        add_action('wp_ajax_ai_chatbot_delete_user_data', array($this, 'delete_user_data'));
        
        // Schedule cleanup tasks
        add_action('ai_chatbot_cleanup_old_data', array($this, 'cleanup_old_data'));
        
        if (!wp_next_scheduled('ai_chatbot_cleanup_old_data')) {
            wp_schedule_event(time(), 'daily', 'ai_chatbot_cleanup_old_data');
        }
    }
    
    public function init_security() {
        // Add security headers
        add_action('send_headers', array($this, 'add_security_headers'));
        
        // Validate and sanitize all inputs
        add_filter('ai_chatbot_sanitize_input', array($this, 'sanitize_input'));
    }
    
    public function add_security_headers() {
        if (!headers_sent()) {
            header('X-Content-Type-Options: nosniff');
            header('X-Frame-Options: SAMEORIGIN');
            header('X-XSS-Protection: 1; mode=block');
        }
    }
    
    public function sanitize_input($input) {
        if (is_array($input)) {
            return array_map(array($this, 'sanitize_input'), $input);
        }
        
        return sanitize_text_field($input);
    }
    
    public function encrypt_data($data) {
        if (!get_option('ai_chatbot_enable_encryption', false)) {
            return $data;
        }
        
        $key = $this->get_encryption_key();
        $iv = openssl_random_pseudo_bytes(16);
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
        
        return base64_encode($iv . $encrypted);
    }
    
    public function decrypt_data($encrypted_data) {
        if (!get_option('ai_chatbot_enable_encryption', false)) {
            return $encrypted_data;
        }
        
        $key = $this->get_encryption_key();
        $data = base64_decode($encrypted_data);
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);
        
        return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
    }
    
    private function get_encryption_key() {
        $key = get_option('ai_chatbot_encryption_key');
        
        if (!$key) {
            $key = wp_generate_password(32, false);
            update_option('ai_chatbot_encryption_key', $key);
        }
        
        return $key;
    }
    
    public function anonymize_user_data() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
            return;
        }
        
        $user_id = intval($_POST['user_id']);
        
        if (!$user_id) {
            wp_send_json_error('Invalid user ID');
            return;
        }
        
        global $wpdb;
        
        $users_table = $wpdb->prefix . 'ai_chatbot_users';
        
        // Anonymize user data
        $anonymized_data = array(
            'name' => 'Anonymous User',
            'email' => 'anonymous@example.com',
            'phone' => '',
            'ip_address' => '0.0.0.0',
            'user_agent' => 'Anonymized'
        );
        
        $result = $wpdb->update(
            $users_table,
            $anonymized_data,
            array('id' => $user_id)
        );
        
        if ($result !== false) {
            wp_send_json_success('User data anonymized successfully');
        } else {
            wp_send_json_error('Failed to anonymize user data');
        }
    }
    
    public function export_user_data() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
            return;
        }
        
        $user_id = intval($_POST['user_id']);
        
        if (!$user_id) {
            wp_send_json_error('Invalid user ID');
            return;
        }
        
        global $wpdb;
        
        $users_table = $wpdb->prefix . 'ai_chatbot_users';
        $conversations_table = $wpdb->prefix . 'ai_chatbot_conversations';
        $messages_table = $wpdb->prefix . 'ai_chatbot_messages';
        
        // Get user data
        $user = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $users_table WHERE id = %d",
            $user_id
        ));
        
        if (!$user) {
            wp_send_json_error('User not found');
            return;
        }
        
        // Get conversations
        $conversations = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $conversations_table WHERE user_id = %d",
            $user_id
        ));
        
        // Get all messages
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT m.* FROM $messages_table m 
             INNER JOIN $conversations_table c ON m.conversation_id = c.id 
             WHERE c.user_id = %d 
             ORDER BY m.created_at ASC",
            $user_id
        ));
        
        // Prepare export data
        $export_data = array(
            'user_info' => array(
                'name' => $user->name,
                'email' => $user->email,
                'phone' => $user->phone,
                'registered_at' => $user->created_at
            ),
            'conversations' => array(),
            'messages' => array()
        );
        
        foreach ($conversations as $conversation) {
            $export_data['conversations'][] = array(
                'id' => $conversation->id,
                'started_at' => $conversation->started_at,
                'ended_at' => $conversation->ended_at,
                'status' => $conversation->status,
                'rating' => $conversation->rating,
                'feedback' => $conversation->feedback
            );
        }
        
        foreach ($messages as $message) {
            $export_data['messages'][] = array(
                'conversation_id' => $message->conversation_id,
                'sender' => $message->sender_type,
                'message' => $message->message,
                'sent_at' => $message->created_at
            );
        }
        
        // Generate filename
        $filename = 'user-data-export-' . $user_id . '-' . date('Y-m-d-H-i-s') . '.json';
        
        wp_send_json_success(array(
            'data' => json_encode($export_data, JSON_PRETTY_PRINT),
            'filename' => $filename
        ));
    }
    
    public function delete_user_data() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
            return;
        }
        
        $user_id = intval($_POST['user_id']);
        
        if (!$user_id) {
            wp_send_json_error('Invalid user ID');
            return;
        }
        
        global $wpdb;
        
        $users_table = $wpdb->prefix . 'ai_chatbot_users';
        $conversations_table = $wpdb->prefix . 'ai_chatbot_conversations';
        $messages_table = $wpdb->prefix . 'ai_chatbot_messages';
        
        // Get conversation IDs for this user
        $conversation_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM $conversations_table WHERE user_id = %d",
            $user_id
        ));
        
        if (!empty($conversation_ids)) {
            $ids_placeholder = implode(',', array_fill(0, count($conversation_ids), '%d'));
            
            // Delete messages
            $wpdb->query($wpdb->prepare(
                "DELETE FROM $messages_table WHERE conversation_id IN ($ids_placeholder)",
                $conversation_ids
            ));
            
            // Delete conversations
            $wpdb->delete($conversations_table, array('user_id' => $user_id));
        }
        
        // Delete user
        $result = $wpdb->delete($users_table, array('id' => $user_id));
        
        if ($result) {
            wp_send_json_success('User data deleted successfully');
        } else {
            wp_send_json_error('Failed to delete user data');
        }
    }
    
    public function cleanup_old_data() {
        $auto_delete_days = intval(get_option('ai_chatbot_auto_delete_days', 30));
        
        if ($auto_delete_days <= 0) {
            return; // Auto-delete disabled
        }
        
        global $wpdb;
        
        $conversations_table = $wpdb->prefix . 'ai_chatbot_conversations';
        $messages_table = $wpdb->prefix . 'ai_chatbot_messages';
        $users_table = $wpdb->prefix . 'ai_chatbot_users';
        
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-$auto_delete_days days"));
        
        // Get old conversation IDs
        $old_conversation_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM $conversations_table WHERE started_at < %s",
            $cutoff_date
        ));
        
        if (!empty($old_conversation_ids)) {
            $ids_placeholder = implode(',', array_fill(0, count($old_conversation_ids), '%d'));
            
            // Delete old messages
            $wpdb->query($wpdb->prepare(
                "DELETE FROM $messages_table WHERE conversation_id IN ($ids_placeholder)",
                $old_conversation_ids
            ));
            
            // Delete old conversations
            $wpdb->query($wpdb->prepare(
                "DELETE FROM $conversations_table WHERE started_at < %s",
                $cutoff_date
            ));
        }
        
        // Delete users with no conversations
        $wpdb->query("
            DELETE u FROM $users_table u 
            LEFT JOIN $conversations_table c ON u.id = c.user_id 
            WHERE c.id IS NULL AND u.created_at < '$cutoff_date'
        ");
        
        // Log cleanup activity
        error_log("AI Chatbot: Cleaned up data older than $auto_delete_days days");
    }
    
    public function validate_file_upload($file) {
        $allowed_types = array('image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'text/plain');
        $max_size = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($file['type'], $allowed_types)) {
            return new WP_Error('invalid_file_type', 'File type not allowed');
        }
        
        if ($file['size'] > $max_size) {
            return new WP_Error('file_too_large', 'File size exceeds limit');
        }
        
        return true;
    }
    
    public function scan_message_for_threats($message) {
        // Basic threat detection
        $threats = array(
            'script', 'javascript:', 'onload=', 'onerror=', 'onclick=',
            'eval(', 'document.cookie', 'window.location'
        );
        
        $message_lower = strtolower($message);
        
        foreach ($threats as $threat) {
            if (strpos($message_lower, $threat) !== false) {
                return true; // Threat detected
            }
        }
        
        return false; // No threats detected
    }
    
    public function rate_limit_check($session_id) {
        $transient_key = 'ai_chatbot_rate_limit_' . md5($session_id);
        $requests = get_transient($transient_key);
        
        if ($requests === false) {
            $requests = 1;
            set_transient($transient_key, $requests, 60); // 1 minute window
        } else {
            $requests++;
            set_transient($transient_key, $requests, 60);
        }
        
        // Allow max 30 requests per minute
        return $requests <= 30;
    }
    
    public function log_security_event($event_type, $details) {
        $log_entry = array(
            'timestamp' => current_time('mysql'),
            'event_type' => $event_type,
            'details' => $details,
            'ip_address' => $this->get_client_ip(),
            'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'])
        );
        
        error_log('AI Chatbot Security Event: ' . json_encode($log_entry));
    }
    
    private function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
}
?>
