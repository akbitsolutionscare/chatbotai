<?php
/**
 * Database management class for AI Chatbot Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIChatbot_Database {
    
    public function __construct() {
        // Constructor
    }
    
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Chat users table
        $users_table = $wpdb->prefix . 'ai_chatbot_users';
        $users_sql = "CREATE TABLE $users_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            phone varchar(20),
            session_id varchar(255) NOT NULL,
            ip_address varchar(45),
            user_agent text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY session_id (session_id),
            KEY email (email)
        ) $charset_collate;";
        
        // Chat conversations table
        $conversations_table = $wpdb->prefix . 'ai_chatbot_conversations';
        $conversations_sql = "CREATE TABLE $conversations_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id mediumint(9) NOT NULL,
            session_id varchar(255) NOT NULL,
            status varchar(20) DEFAULT 'active',
            rating tinyint(1) DEFAULT NULL,
            feedback text,
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            ended_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY session_id (session_id),
            KEY status (status)
        ) $charset_collate;";
        
        // Chat messages table
        $messages_table = $wpdb->prefix . 'ai_chatbot_messages';
        $messages_sql = "CREATE TABLE $messages_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            conversation_id mediumint(9) NOT NULL,
            sender_type enum('user','bot') NOT NULL,
            message text NOT NULL,
            message_type varchar(20) DEFAULT 'text',
            metadata json,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY conversation_id (conversation_id),
            KEY sender_type (sender_type),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // FAQ table
        $faq_table = $wpdb->prefix . 'ai_chatbot_faq';
        $faq_sql = "CREATE TABLE $faq_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            question text NOT NULL,
            answer text NOT NULL,
            category varchar(100),
            keywords text,
            usage_count int DEFAULT 0,
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY category (category),
            KEY is_active (is_active),
            FULLTEXT KEY question_answer (question, answer)
        ) $charset_collate;";
        
        // Crawled content table
        $content_table = $wpdb->prefix . 'ai_chatbot_content';
        $content_sql = "CREATE TABLE $content_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            url varchar(500) NOT NULL,
            title varchar(255),
            content longtext,
            meta_description text,
            keywords text,
            last_crawled datetime DEFAULT CURRENT_TIMESTAMP,
            is_active tinyint(1) DEFAULT 1,
            PRIMARY KEY (id),
            UNIQUE KEY url (url),
            KEY is_active (is_active),
            FULLTEXT KEY content_search (title, content, meta_description)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        dbDelta($users_sql);
        dbDelta($conversations_sql);
        dbDelta($messages_sql);
        dbDelta($faq_sql);
        dbDelta($content_sql);
        
        // Insert default FAQ entries
        self::insert_default_faq();
    }
    
    private static function insert_default_faq() {
        global $wpdb;
        
        $faq_table = $wpdb->prefix . 'ai_chatbot_faq';
        
        $default_faqs = array(
            array(
                'question' => 'What are your business hours?',
                'answer' => 'We are open Monday to Friday, 9 AM to 6 PM EST.',
                'category' => 'General',
                'keywords' => 'hours, time, open, closed, schedule'
            ),
            array(
                'question' => 'How can I contact support?',
                'answer' => 'You can contact our support team via email at support@example.com or through this chat.',
                'category' => 'Support',
                'keywords' => 'contact, support, help, email'
            ),
            array(
                'question' => 'What payment methods do you accept?',
                'answer' => 'We accept all major credit cards, PayPal, and bank transfers.',
                'category' => 'Payment',
                'keywords' => 'payment, credit card, paypal, bank transfer'
            )
        );
        
        foreach ($default_faqs as $faq) {
            $wpdb->insert($faq_table, $faq);
        }
    }
    
    public static function get_user_by_session($session_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'ai_chatbot_users';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE session_id = %s",
            $session_id
        ));
    }
    
    public static function create_user($data) {
        global $wpdb;
        $table = $wpdb->prefix . 'ai_chatbot_users';
        
        $result = $wpdb->insert($table, $data);
        
        if ($result) {
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    public static function create_conversation($user_id, $session_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'ai_chatbot_conversations';
        
        $data = array(
            'user_id' => $user_id,
            'session_id' => $session_id,
            'status' => 'active'
        );
        
        $result = $wpdb->insert($table, $data);
        
        if ($result) {
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    public static function add_message($conversation_id, $sender_type, $message, $message_type = 'text', $metadata = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'ai_chatbot_messages';
        
        $data = array(
            'conversation_id' => $conversation_id,
            'sender_type' => $sender_type,
            'message' => $message,
            'message_type' => $message_type
        );
        
        if ($metadata) {
            $data['metadata'] = json_encode($metadata);
        }
        
        return $wpdb->insert($table, $data);
    }
    
    public static function get_conversation_messages($conversation_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'ai_chatbot_messages';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE conversation_id = %d ORDER BY created_at ASC",
            $conversation_id
        ));
    }
    
    public static function search_faq($query) {
        global $wpdb;
        $table = $wpdb->prefix . 'ai_chatbot_faq';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT *, MATCH(question, answer) AGAINST(%s IN NATURAL LANGUAGE MODE) as relevance 
             FROM $table 
             WHERE is_active = 1 AND MATCH(question, answer) AGAINST(%s IN NATURAL LANGUAGE MODE)
             ORDER BY relevance DESC 
             LIMIT 3",
            $query, $query
        ));
        
        return $results;
    }
    
    public static function search_content($query) {
        global $wpdb;
        $table = $wpdb->prefix . 'ai_chatbot_content';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT *, MATCH(title, content, meta_description) AGAINST(%s IN NATURAL LANGUAGE MODE) as relevance 
             FROM $table 
             WHERE is_active = 1 AND MATCH(title, content, meta_description) AGAINST(%s IN NATURAL LANGUAGE MODE)
             ORDER BY relevance DESC 
             LIMIT 3",
            $query, $query
        ));
        
        return $results;
    }
    
    public static function get_conversations($limit = 50, $offset = 0, $filters = array()) {
        global $wpdb;
        
        $conversations_table = $wpdb->prefix . 'ai_chatbot_conversations';
        $users_table = $wpdb->prefix . 'ai_chatbot_users';
        
        $where_clauses = array('1=1');
        $where_values = array();
        
        if (!empty($filters['date_from'])) {
            $where_clauses[] = 'c.started_at >= %s';
            $where_values[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where_clauses[] = 'c.started_at <= %s';
            $where_values[] = $filters['date_to'];
        }
        
        if (!empty($filters['rating'])) {
            $where_clauses[] = 'c.rating = %d';
            $where_values[] = $filters['rating'];
        }
        
        $where_sql = implode(' AND ', $where_clauses);
        
        $sql = "SELECT c.*, u.name, u.email 
                FROM $conversations_table c 
                LEFT JOIN $users_table u ON c.user_id = u.id 
                WHERE $where_sql 
                ORDER BY c.started_at DESC 
                LIMIT %d OFFSET %d";
        
        $where_values[] = $limit;
        $where_values[] = $offset;
        
        if (!empty($where_values)) {
            return $wpdb->get_results($wpdb->prepare($sql, $where_values));
        } else {
            return $wpdb->get_results($sql);
        }
    }
}
?>
