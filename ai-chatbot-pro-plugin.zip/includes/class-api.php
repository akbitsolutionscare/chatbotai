<?php
/**
 * API class for AI Chatbot Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIChatbot_API {
    
    private $openai_api_key;
    private $openai_model;
    private $max_tokens;
    private $temperature;
    private $system_prompt;
    
    public function __construct() {
        $this->openai_api_key = get_option('ai_chatbot_openai_api_key');
        $this->openai_model = get_option('ai_chatbot_openai_model', 'gpt-3.5-turbo');
        $this->max_tokens = intval(get_option('ai_chatbot_max_tokens', 150));
        $this->temperature = floatval(get_option('ai_chatbot_temperature', 0.7));
        $this->system_prompt = get_option('ai_chatbot_system_prompt', 'You are a helpful assistant.');
        
        add_action('wp_ajax_ai_chatbot_send_message', array($this, 'handle_message'));
        add_action('wp_ajax_nopriv_ai_chatbot_send_message', array($this, 'handle_message'));
        add_action('wp_ajax_ai_chatbot_save_user', array($this, 'save_user'));
        add_action('wp_ajax_nopriv_ai_chatbot_save_user', array($this, 'save_user'));
        add_action('wp_ajax_ai_chatbot_rate_conversation', array($this, 'rate_conversation'));
        add_action('wp_ajax_nopriv_ai_chatbot_rate_conversation', array($this, 'rate_conversation'));
    }
    
    public function save_user() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $session_id = sanitize_text_field($_POST['session_id']);
        
        if (empty($name) || empty($email) || empty($session_id)) {
            wp_send_json_error('Missing required fields');
            return;
        }
        
        // Check if user already exists
        $existing_user = AIChatbot_Database::get_user_by_session($session_id);
        
        if ($existing_user) {
            wp_send_json_success(array(
                'user_id' => $existing_user->id,
                'message' => 'User already exists'
            ));
            return;
        }
        
        // Create new user
        $user_data = array(
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'session_id' => $session_id,
            'ip_address' => $this->get_client_ip(),
            'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'])
        );
        
        $user_id = AIChatbot_Database::create_user($user_data);
        
        if ($user_id) {
            // Create conversation
            $conversation_id = AIChatbot_Database::create_conversation($user_id, $session_id);
            
            wp_send_json_success(array(
                'user_id' => $user_id,
                'conversation_id' => $conversation_id,
                'message' => 'User created successfully'
            ));
        } else {
            wp_send_json_error('Failed to create user');
        }
    }
    
    public function handle_message() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        $message = sanitize_textarea_field($_POST['message']);
        $session_id = sanitize_text_field($_POST['session_id']);
        $conversation_id = intval($_POST['conversation_id']);
        
        if (empty($message) || empty($session_id)) {
            wp_send_json_error('Missing required fields');
            return;
        }
        
        // Save user message
        AIChatbot_Database::add_message($conversation_id, 'user', $message);
        
        // Try to find answer in FAQ first
        $faq_response = $this->search_knowledge_base($message);
        
        if ($faq_response) {
            // Save bot response
            AIChatbot_Database::add_message($conversation_id, 'bot', $faq_response['answer'], 'text', array('source' => 'faq', 'faq_id' => $faq_response['id']));
            
            // Update FAQ usage count
            $this->update_faq_usage($faq_response['id']);
            
            wp_send_json_success(array(
                'response' => $faq_response['answer'],
                'source' => 'faq'
            ));
            return;
        }
        
        // If no FAQ match, use OpenAI
        $ai_response = $this->get_openai_response($message, $conversation_id);
        
        if ($ai_response) {
            // Save bot response
            AIChatbot_Database::add_message($conversation_id, 'bot', $ai_response, 'text', array('source' => 'openai'));
            
            wp_send_json_success(array(
                'response' => $ai_response,
                'source' => 'ai'
            ));
        } else {
            wp_send_json_error('Failed to get AI response');
        }
    }
    
    private function search_knowledge_base($query) {
        // Search FAQ
        $faq_results = AIChatbot_Database::search_faq($query);
        
        if (!empty($faq_results) && $faq_results[0]->relevance > 0.5) {
            return array(
                'id' => $faq_results[0]->id,
                'answer' => $faq_results[0]->answer,
                'relevance' => $faq_results[0]->relevance
            );
        }
        
        // Search crawled content
        $content_results = AIChatbot_Database::search_content($query);
        
        if (!empty($content_results) && $content_results[0]->relevance > 0.5) {
            // Extract relevant snippet from content
            $snippet = $this->extract_relevant_snippet($content_results[0]->content, $query);
            
            return array(
                'id' => $content_results[0]->id,
                'answer' => $snippet,
                'relevance' => $content_results[0]->relevance
            );
        }
        
        return false;
    }
    
    private function extract_relevant_snippet($content, $query) {
        // Simple snippet extraction - can be improved with more sophisticated algorithms
        $sentences = preg_split('/[.!?]+/', $content);
        $query_words = explode(' ', strtolower($query));
        
        $best_sentence = '';
        $best_score = 0;
        
        foreach ($sentences as $sentence) {
            $sentence = trim($sentence);
            if (strlen($sentence) < 20) continue;
            
            $score = 0;
            foreach ($query_words as $word) {
                if (stripos($sentence, $word) !== false) {
                    $score++;
                }
            }
            
            if ($score > $best_score) {
                $best_score = $score;
                $best_sentence = $sentence;
            }
        }
        
        return $best_sentence ?: substr($content, 0, 200) . '...';
    }
    
    private function get_openai_response($message, $conversation_id) {
        if (empty($this->openai_api_key)) {
            return 'I apologize, but the AI service is not configured. Please contact the administrator.';
        }
        
        // Get conversation history for context
        $messages = AIChatbot_Database::get_conversation_messages($conversation_id);
        
        // Build conversation context
        $conversation_context = array();
        $conversation_context[] = array(
            'role' => 'system',
            'content' => $this->system_prompt
        );
        
        // Add recent messages for context (limit to last 10 messages)
        $recent_messages = array_slice($messages, -10);
        
        foreach ($recent_messages as $msg) {
            $role = $msg->sender_type === 'user' ? 'user' : 'assistant';
            $conversation_context[] = array(
                'role' => $role,
                'content' => $msg->message
            );
        }
        
        // Add current message
        $conversation_context[] = array(
            'role' => 'user',
            'content' => $message
        );
        
        // Make API request to OpenAI
        $response = $this->call_openai_api($conversation_context);
        
        return $response;
    }
    
    private function call_openai_api($messages) {
        $url = 'https://api.openai.com/v1/chat/completions';
        
        $data = array(
            'model' => $this->openai_model,
            'messages' => $messages,
            'max_tokens' => $this->max_tokens,
            'temperature' => $this->temperature,
            'top_p' => 1,
            'frequency_penalty' => 0,
            'presence_penalty' => 0
        );
        
        $headers = array(
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->openai_api_key
        );
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code !== 200) {
            error_log('OpenAI API Error: HTTP ' . $http_code . ' - ' . $response);
            return 'I apologize, but I am experiencing technical difficulties. Please try again later.';
        }
        
        $response_data = json_decode($response, true);
        
        if (isset($response_data['choices'][0]['message']['content'])) {
            return trim($response_data['choices'][0]['message']['content']);
        }
        
        return 'I apologize, but I could not process your request. Please try again.';
    }
    
    private function update_faq_usage($faq_id) {
        global $wpdb;
        
        $faq_table = $wpdb->prefix . 'ai_chatbot_faq';
        
        $wpdb->query($wpdb->prepare(
            "UPDATE $faq_table SET usage_count = usage_count + 1 WHERE id = %d",
            $faq_id
        ));
    }
    
    public function rate_conversation() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        $conversation_id = intval($_POST['conversation_id']);
        $rating = intval($_POST['rating']);
        $feedback = sanitize_textarea_field($_POST['feedback']);
        
        if ($conversation_id && $rating >= 1 && $rating <= 5) {
            global $wpdb;
            
            $conversations_table = $wpdb->prefix . 'ai_chatbot_conversations';
            
            $result = $wpdb->update(
                $conversations_table,
                array(
                    'rating' => $rating,
                    'feedback' => $feedback,
                    'ended_at' => current_time('mysql')
                ),
                array('id' => $conversation_id)
            );
            
            if ($result !== false) {
                wp_send_json_success('Rating saved successfully');
            } else {
                wp_send_json_error('Failed to save rating');
            }
        } else {
            wp_send_json_error('Invalid rating data');
        }
    }
    
    private function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
    
    public function download_transcript() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        $conversation_id = intval($_POST['conversation_id']);
        
        if (!$conversation_id) {
            wp_send_json_error('Invalid conversation ID');
            return;
        }
        
        $messages = AIChatbot_Database::get_conversation_messages($conversation_id);
        
        $transcript = "Chat Transcript\n";
        $transcript .= "Generated on: " . date('Y-m-d H:i:s') . "\n\n";
        
        foreach ($messages as $message) {
            $sender = $message->sender_type === 'user' ? 'You' : 'AI Assistant';
            $time = date('H:i', strtotime($message->created_at));
            $transcript .= "[$time] $sender: " . $message->message . "\n";
        }
        
        wp_send_json_success(array(
            'transcript' => $transcript,
            'filename' => 'chat-transcript-' . date('Y-m-d-H-i-s') . '.txt'
        ));
    }
}
?>
