<?php
/**
 * Admin dashboard class for AI Chatbot Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIChatbot_Admin {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_ai_chatbot_delete_conversation', array($this, 'delete_conversation'));
        add_action('wp_ajax_ai_chatbot_bulk_delete', array($this, 'bulk_delete_conversations'));
        add_action('wp_ajax_ai_chatbot_export_data', array($this, 'export_user_data'));
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'AI Chatbot Pro',
            'AI Chatbot',
            'manage_options',
            'ai-chatbot-dashboard',
            array($this, 'dashboard_page'),
            'dashicons-format-chat',
            30
        );
        
        add_submenu_page(
            'ai-chatbot-dashboard',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'ai-chatbot-dashboard',
            array($this, 'dashboard_page')
        );
        
        add_submenu_page(
            'ai-chatbot-dashboard',
            'Conversations',
            'Conversations',
            'manage_options',
            'ai-chatbot-conversations',
            array($this, 'conversations_page')
        );
        
        add_submenu_page(
            'ai-chatbot-dashboard',
            'Users',
            'Users',
            'manage_options',
            'ai-chatbot-users',
            array($this, 'users_page')
        );
        
        add_submenu_page(
            'ai-chatbot-dashboard',
            'FAQ Management',
            'FAQ',
            'manage_options',
            'ai-chatbot-faq',
            array($this, 'faq_page')
        );
        
        add_submenu_page(
            'ai-chatbot-dashboard',
            'Settings',
            'Settings',
            'manage_options',
            'ai-chatbot-settings',
            array($this, 'settings_page')
        );
        
        add_submenu_page(
            'ai-chatbot-dashboard',
            'Analytics',
            'Analytics',
            'manage_options',
            'ai-chatbot-analytics',
            array($this, 'analytics_page')
        );
    }
    
    public function register_settings() {
        // General Settings
        register_setting('ai_chatbot_general', 'ai_chatbot_widget_position');
        register_setting('ai_chatbot_general', 'ai_chatbot_primary_color');
        register_setting('ai_chatbot_general', 'ai_chatbot_greeting_message');
        register_setting('ai_chatbot_general', 'ai_chatbot_require_user_info');
        register_setting('ai_chatbot_general', 'ai_chatbot_enable_file_upload');
        
        // AI Settings
        register_setting('ai_chatbot_ai', 'ai_chatbot_openai_api_key');
        register_setting('ai_chatbot_ai', 'ai_chatbot_openai_model');
        register_setting('ai_chatbot_ai', 'ai_chatbot_max_tokens');
        register_setting('ai_chatbot_ai', 'ai_chatbot_temperature');
        register_setting('ai_chatbot_ai', 'ai_chatbot_system_prompt');
        
        // Data Management
        register_setting('ai_chatbot_data', 'ai_chatbot_auto_delete_days');
        register_setting('ai_chatbot_data', 'ai_chatbot_enable_encryption');
    }
    
    public function dashboard_page() {
        global $wpdb;
        
        // Get statistics
        $stats = $this->get_dashboard_stats();
        
        ?>
        <div class="wrap">
            <h1>AI Chatbot Pro Dashboard</h1>
            
            <div class="ai-chatbot-dashboard">
                <div class="stats-grid">
                    <div class="stat-card">
                        <h3>Total Conversations</h3>
                        <div class="stat-number"><?php echo $stats['total_conversations']; ?></div>
                    </div>
                    
                    <div class="stat-card">
                        <h3>Active Users</h3>
                        <div class="stat-number"><?php echo $stats['total_users']; ?></div>
                    </div>
                    
                    <div class="stat-card">
                        <h3>Messages Today</h3>
                        <div class="stat-number"><?php echo $stats['messages_today']; ?></div>
                    </div>
                    
                    <div class="stat-card">
                        <h3>Average Rating</h3>
                        <div class="stat-number"><?php echo $stats['avg_rating']; ?>/5</div>
                    </div>
                </div>
                
                <div class="dashboard-widgets">
                    <div class="widget recent-conversations">
                        <h3>Recent Conversations</h3>
                        <?php $this->display_recent_conversations(); ?>
                    </div>
                    
                    <div class="widget popular-questions">
                        <h3>Popular Questions</h3>
                        <?php $this->display_popular_questions(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    private function get_dashboard_stats() {
        global $wpdb;
        
        $conversations_table = $wpdb->prefix . 'ai_chatbot_conversations';
        $users_table = $wpdb->prefix . 'ai_chatbot_users';
        $messages_table = $wpdb->prefix . 'ai_chatbot_messages';
        
        $stats = array();
        
        $stats['total_conversations'] = $wpdb->get_var("SELECT COUNT(*) FROM $conversations_table");
        $stats['total_users'] = $wpdb->get_var("SELECT COUNT(*) FROM $users_table");
        $stats['messages_today'] = $wpdb->get_var("SELECT COUNT(*) FROM $messages_table WHERE DATE(created_at) = CURDATE()");
        $stats['avg_rating'] = $wpdb->get_var("SELECT ROUND(AVG(rating), 1) FROM $conversations_table WHERE rating IS NOT NULL") ?: 0;
        
        return $stats;
    }
    
    public function conversations_page() {
        // Conversations management page content
        echo '<div class="wrap"><h1>Conversations Management</h1></div>';
    }
    
    public function users_page() {
        // Users management page content
        echo '<div class="wrap"><h1>Users Management</h1></div>';
    }
    
    public function faq_page() {
        // FAQ management page content
        echo '<div class="wrap"><h1>FAQ Management</h1></div>';
    }
    
    public function settings_page() {
        // Settings page content
        echo '<div class="wrap"><h1>AI Chatbot Settings</h1></div>';
    }
    
    public function analytics_page() {
        // Analytics page content
        echo '<div class="wrap"><h1>Analytics</h1></div>';
    }
    
    private function display_recent_conversations() {
        $conversations = AIChatbot_Database::get_conversations(5);
        
        if (empty($conversations)) {
            echo '<p>No conversations yet.</p>';
            return;
        }
        
        echo '<ul>';
        foreach ($conversations as $conversation) {
            echo '<li>';
            echo '<strong>' . esc_html($conversation->name) . '</strong> - ';
            echo date('M j, Y H:i', strtotime($conversation->started_at));
            echo '</li>';
        }
        echo '</ul>';
    }
    
    private function display_popular_questions() {
        global $wpdb;
        
        $faq_table = $wpdb->prefix . 'ai_chatbot_faq';
        $popular_faqs = $wpdb->get_results("SELECT question, usage_count FROM $faq_table WHERE usage_count > 0 ORDER BY usage_count DESC LIMIT 5");
        
        if (empty($popular_faqs)) {
            echo '<p>No FAQ usage data yet.</p>';
            return;
        }
        
        echo '<ul>';
        foreach ($popular_faqs as $faq) {
            echo '<li>';
            echo esc_html(substr($faq->question, 0, 50)) . '... ';
            echo '<span class="usage-count">(' . $faq->usage_count . ' uses)</span>';
            echo '</li>';
        }
        echo '</ul>';
    }
    
    public function delete_conversation() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $conversation_id = intval($_POST['conversation_id']);
        
        global $wpdb;
        
        $conversations_table = $wpdb->prefix . 'ai_chatbot_conversations';
        $messages_table = $wpdb->prefix . 'ai_chatbot_messages';
        
        // Delete messages first
        $wpdb->delete($messages_table, array('conversation_id' => $conversation_id));
        
        // Delete conversation
        $result = $wpdb->delete($conversations_table, array('id' => $conversation_id));
        
        if ($result) {
            wp_send_json_success('Conversation deleted successfully');
        } else {
            wp_send_json_error('Failed to delete conversation');
        }
    }
    
    public function bulk_delete_conversations() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $conversation_ids = array_map('intval', $_POST['conversation_ids']);
        
        global $wpdb;
        
        $conversations_table = $wpdb->prefix . 'ai_chatbot_conversations';
        $messages_table = $wpdb->prefix . 'ai_chatbot_messages';
        
        $ids_placeholder = implode(',', array_fill(0, count($conversation_ids), '%d'));
        
        // Delete messages first
        $wpdb->query($wpdb->prepare("DELETE FROM $messages_table WHERE conversation_id IN ($ids_placeholder)", $conversation_ids));
        
        // Delete conversations
        $result = $wpdb->query($wpdb->prepare("DELETE FROM $conversations_table WHERE id IN ($ids_placeholder)", $conversation_ids));
        
        if ($result) {
            wp_send_json_success('Conversations deleted successfully');
        } else {
            wp_send_json_error('Failed to delete conversations');
        }
    }
    
    public function export_user_data() {
        check_ajax_referer('ai_chatbot_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $user_id = intval($_POST['user_id']);
        
        // Export user data logic here
        wp_send_json_success('User data exported successfully');
    }
}
?>
